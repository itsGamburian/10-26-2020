// Hambartzum Mike Gamburian
// 10/26/2020

import java.util.*;
import java.io.*;

public class MatricesDriver
{

    public static void main(String[] args) {
   
        
        Scanner input = new Scanner(System.in);
        String cmd;

        System.out.println("Welcome to Matrices. \nWould you like to create a new matrix or would you like to use the existing matrix in the file database?");
        System.out.println("Enter \"new\" or \"existing\", any other input will terminate the program...");
        cmd = input.nextLine().toLowerCase(); //Waiting for response from user
   
        int rows = 0;
        int cols = 0;
        switch(cmd) 
        {
            
            case "new":
                System.out.println("We need the dimensions of the matrix.\nEnter number of rows as an integer: ");
                try {
                    rows = input.nextInt();
                }
                catch (Exception e) {
                    System.out.println("You must enter an integer number!");
                    System.out.println("Error Code: " + e);
                }

                System.out.println("Enter number of columns as an integer: ");
                try {
                    cols = input.nextInt();
                }
                catch (Exception e) {
                    System.out.println("You must enter an integer number!");
                    System.out.println("Error Code: " + e);
                }
                Matrices matrices1 = new Matrices(rows, cols);
                System.out.println("Matrix created! Feel free to type enter \"quit\" to exit the program and save the matrix to the output file.");





                while (!cmd.equals("quit")) {
                    System.out.println("--------------------------------------------------------------------");
                    System.out.println("Enter a command: transpose, multiply by scalar, show matrix, or quit");
                    cmd = input.nextLine().toLowerCase();
                    
                    if (cmd.contains("show")) {
                        matrices1.prettyMatrix();
                    }
                    
                    
                    if (cmd.contains("tra")) {
                        System.out.println("Here\'s the original matrix again.\n");
                        matrices1.prettyMatrix();
                        System.out.println("Here\'s the transposed matrix.\n");
                        matrices1.prettyMatrix( matrices1.transpose() );
                        matrices1.replaceMatrix( matrices1.transpose() );
                    }
                    
                    
                    if (cmd.contains("mult")) {
                        System.out.println("Enter a scalar to multiple the original matrix by. You can view the original matrix again by entering \"show matrix\".");
                        float scalar1 = input.nextFloat();
                        System.out.println("Here\'s the original matrix again.\n");
                        matrices1.prettyMatrix();
                        System.out.println("Here\'s the product matrix.\n");
                        matrices1.prettyMatrix( matrices1.multiply(scalar1) );    
                        matrices1.replaceMatrix( matrices1.multiply(scalar1) );
                    }
                    
                    
                }








                
                System.out.println("Writing to \"output.txt\" file. Goodbye...");
                matrices1.writeToFile();
                break;



 /****************************************************** */            
 
 
            case "existing":
                Matrices matrices2 = new Matrices();
                System.out.println("Loading the contents of the existing matrix...");
                File file = new File("input.txt");
                if (file.exists())
                    matrices2.readInitialFromFile();
                System.out.println("Matrix loaded! Feel free to type enter \"quit\" to exit the program and save the matrix to the output file.");




                while (!cmd.equals("quit")) {
                    System.out.println("--------------------------------------------------------------------");
                    System.out.println("Enter a command: transpose, multiply by scalar, show matrix, or quit");
                    cmd = input.nextLine().toLowerCase();
                    
                    if (cmd.contains("show")) {
                        matrices2.prettyMatrix();
                    }
                    
                    
                    if (cmd.contains("tra")) {
                        System.out.println("Here\'s the original matrix again.\n");
                        matrices2.prettyMatrix();
                        System.out.println("Here\'s the transposed matrix.\n");
                        matrices2.prettyMatrix( matrices2.transpose() );
                        matrices2.replaceMatrix( matrices2.transpose() );
                    }
                    
                    
                    if (cmd.contains("mult")) {
                        System.out.println("Enter a scalar to multiple the original matrix by. You can view the original matrix again by entering \"show matrix\".");
                        float scalar2 = input.nextFloat();
                        System.out.println("Here\'s the original matrix again.\n");
                        matrices2.prettyMatrix();
                        System.out.println("Here\'s the product matrix.\n");
                        matrices2.prettyMatrix( matrices2.multiply(scalar2) );    
                        matrices2.replaceMatrix( matrices2.multiply(scalar2) );
                    }
                    
                }



                System.out.println("Writing to \"output.txt\" file. Goodbye...");
                matrices2.writeToFile();
                break;
        }
        
               
   } 
}