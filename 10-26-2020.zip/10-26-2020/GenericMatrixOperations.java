// Hambartzum Mike Gamburian
// 10/26/2020

import java.util.*;
import java.io.*;

public class GenericMatrixOperations
{

   public GenericMatrixOperations()
   {
   }

    public float[][] transpose(float[][] matrix)
    {
        int rows = getNumOfRowsCols(matrix)[0];
        int cols = getNumOfRowsCols(matrix)[1];

        float[][] temp = new float[cols][rows];
        for (int col = 0; col < rows; col++) {
            for (int row = 0; row < cols; row++) {
                temp[row][col] = matrix[col][row];
            }
        }
        return temp;
    }

    public float[][] add(float[][] matrix1, float[][] matrix2)
    {
        int rows1 = getNumOfRowsCols(matrix1)[0];
        int cols1 = getNumOfRowsCols(matrix1)[1];
        int rows2 = getNumOfRowsCols(matrix2)[0];
        int cols2 = getNumOfRowsCols(matrix2)[1];

        if (!(rows1 == rows2 && cols1 == cols2)) {
            System.out.println("Error, cannot add matrices that are not the same size.");
            return new float[][] { };
        }
        else {
            float[][] temp = new float[rows1][cols1];
            for (int row = 0; row < rows1; row++) {
                for (int col = 0; col < cols1; col++) {
                    temp[row][col] = matrix1[row][col] + matrix2[row][col];
                }
            }
            return temp;
        }
    }

    public float[][] subtract(float[][] matrix1, float[][] matrix2)
    {
        int rows1 = getNumOfRowsCols(matrix1)[0];
        int cols1 = getNumOfRowsCols(matrix1)[1];
        int rows2 = getNumOfRowsCols(matrix2)[0];
        int cols2 = getNumOfRowsCols(matrix2)[1];

        if (!(rows1 == rows2 && cols1 == cols2)) {
            System.out.println("Error, cannot subtract matrices that are not the same size.");
            return new float[][] { };
        }
        else {
            float[][] temp = new float[rows1][cols1];
            for (int row = 0; row < rows1; row++) {
                for (int col = 0; col < cols1; col++) {
                    temp[row][col] = matrix1[row][col] - matrix2[row][col];
                }
            }
            return temp;
        }
    }

    public float[][] multiply(float scalar, float[][] matrix)
    {
        int rows = getNumOfRowsCols(matrix)[0];
        int cols = getNumOfRowsCols(matrix)[1];

        float[][] temp = new float[rows][cols];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                temp[row][col] = scalar * matrix[row][col];
            }
        }
        return temp;
    }

    public float[][] multiply(float[][] matrix1, float[][] matrix2) 
    {
        int rows1 = getNumOfRowsCols(matrix1)[0];
        int cols1 = getNumOfRowsCols(matrix1)[1];
        int rows2 = getNumOfRowsCols(matrix2)[0];
        int cols2 = getNumOfRowsCols(matrix2)[1];

        if (rows2 != cols1) { 
            System.out.println("Error, multiplication is impossible."); 
            return new float[][] { }; 
        }
        else {
            float[][] temp = new float[rows1][cols2];
            for (int i = 0; i < rows1; i++) { 
                for (int j = 0; j < cols2; j++) { 
                    for (int k = 0; k < rows2; k++) {
                        temp[i][j] += matrix1[i][k] * matrix2[k][j]; 
                    }
                }
            }
            return temp;
        }
    }

    public int[] getNumOfRowsCols(float[][] matrix) 
    {
        int numOfRows = matrix.length;
        int numOfCols = 0;
        for (int row = 0; row < 1; row++) {
            numOfCols = matrix[row].length;
        }
        return new int[] {numOfRows, numOfCols};
    }

    public void prettyMatrix(float[][] matrix) 
    {
        for (int row = 0; row < matrix.length; row++) {
                for (int col = 0; col < matrix[row].length; col++) {
                    if (matrix[row][col] == (float)0.0) {
                        System.out.print("  |  0.0");
                    }
                    else {
                        System.out.printf("  |  %2.1f", matrix[row][col]);
                    }
                }
            System.out.print("  |");
            System.out.println();
        }
    }

}