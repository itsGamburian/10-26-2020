// Hambartzum Mike Gamburian
// 10/26/2020

import java.util.*;
import java.io.*;

public class GenericMatrixOperationsDriver 
{
    public static void main (String[] args)
    {

        float[][] matrix1 = {
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
        };

        float[][] matrix2 = {
            {4, 5, 6, 7, 8},
            {13, 12, 11, 10, 9},
            {14, 15, 16, 17, 18},
            {23, 22, 21, 20, 19},
        };

        float[][] matrix3 = {
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
            {1, 2, 3, 4, 5},
        };

        float[][] matrix4 = {
            {101, 102, 103, 104, 105},
            {101, 102, 103, 104, 105},
            {101, 102, 103, 104, 105},
            {101, 102, 103, 104, 105},
            {101, 102, 103, 104, 105},
        };

        float[][] matrix5 = {
            {5, 6, 7},
            {5, 6, 7},
        };

        float[][] matrix6 = {
            {1, 2, 3, 4},
            {1, 2, 3, 4},
        };

        float[][] matrix7 = {
            {5, 6, 7},
            {5, 6, 7},
        };

        float[][] matrix8 = {
            {1, 2, 3, 4},
            {1, 2, 3, 4},
            {1, 2, 3, 4},
        };


        
        GenericMatrixOperations matrixOps = new GenericMatrixOperations();



        System.out.println("Matrix1 is: ");
        matrixOps.prettyMatrix(matrix1);
        System.out.println("\nTransposing Matrix Now...\n");
        matrixOps.prettyMatrix( matrixOps.transpose(matrix1) );
        System.out.println("\n\n\n\n");


        
        System.out.println("Matrix1 is: ");
        matrixOps.prettyMatrix(matrix3);
        System.out.println("Matrix2 is: ");
        matrixOps.prettyMatrix(matrix4);
        System.out.println("Adding them up is: ");
        matrixOps.prettyMatrix( matrixOps.add(matrix3, matrix4) );
        System.out.println("\n\n\n\n");



        System.out.println("Matrix1 is: ");
        matrixOps.prettyMatrix(matrix3);
        System.out.println("Matrix2 is: ");
        matrixOps.prettyMatrix(matrix4);
        System.out.println("Subtracting them is: ");
        matrixOps.prettyMatrix( matrixOps.subtract(matrix3, matrix4) );
        System.out.println("\n\n\n\n");



        System.out.println("Going to mulitply this matrix by 2: ");
        matrixOps.prettyMatrix(matrix1);
        System.out.println("This matrix multiplied by 2 is: ");
        matrixOps.prettyMatrix( matrixOps.multiply(2, matrix1) );
        System.out.println("\n\n\n\n");



        System.out.println("Going to mulitply this matrix by this matrix: ");
        matrixOps.prettyMatrix(matrix5);
        System.out.println("This matrix multiplied by, the product of these matrices should be impossible");
        matrixOps.prettyMatrix(matrix6);
        System.out.println("This product of the matrices is: ");
        matrixOps.prettyMatrix( matrixOps.multiply(matrix5, matrix6) );
        System.out.println("\n\n\n\n");



        System.out.println("Going to mulitply this matrix by this matrix: ");
        matrixOps.prettyMatrix(matrix5);
        System.out.println("This matrix multiplied by ");
        matrixOps.prettyMatrix(matrix6);
        System.out.println("This product of the matrices is: ");
        matrixOps.prettyMatrix( matrixOps.multiply(matrix7, matrix8) );
        System.out.println("\n\n\n\n");
    }
}