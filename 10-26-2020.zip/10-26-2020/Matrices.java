// Hambartzum Mike Gamburian
// 10/26/2020

import java.util.*;
import java.io.*;

public class Matrices
{
    private float[][] matrix;
    private int rows = 0;
    private int cols = 0;
    Scanner input;
    File file1;
    Random rand = new Random();

    public Matrices()
    {
        rows = 2;
        cols = 2;

        matrix = new float[rows][cols];

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                matrix[row][col] = rand.nextFloat();
            }
        }
    }

    public Matrices(int rows, int cols)
    {
        this.rows = rows;
        this.cols = cols;

        matrix = new float[rows][cols];

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                matrix[row][col] = rand.nextFloat();
            }
        }
    }

    public Matrices(float[][] anotherMatrix)
    {
        rows = getNumOfRowsCols(anotherMatrix)[0];
        cols = getNumOfRowsCols(anotherMatrix)[1];

        matrix = new float[rows][cols];
 
        for (int row = 0; row < rows; row++) 
        {
            for (int col = 0; col < cols; col++)
            {
                matrix[row][col] = (float) anotherMatrix[row][col];
            }
        }
 
    }

    public void modify(int row, int col, float value) {
        matrix[row][col] = value;
    }

    public void replaceMatrix(float[][] anotherMatrix) {
        rows = getNumOfRowsCols(anotherMatrix)[0];
        cols = getNumOfRowsCols(anotherMatrix)[1];

        float[][] temp = new float[rows][cols];
 
        for (int row = 0; row < rows; row++) 
        {
            for (int col = 0; col < cols; col++)
            {
                temp[row][col] = (float) anotherMatrix[row][col];
            }
        }

        matrix = temp;
    }


     public void readInitialFromFile() {
        try {
            input = new Scanner(new File("input.txt")); }
        catch(FileNotFoundException e) {
            System.out.println("The \"input.txt\" file is either corrupt or not is not found.");
            return; 
        }
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                matrix[row][col] = input.nextFloat();
            }
        }
    }

    public void writeToFile() {
        file1 = new File("output.txt");
        try {
            PrintWriter output = new PrintWriter(file1);
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    output.print(matrix[row][col] + " ");
                }
                output.println();
            }
            output.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("The \"output.txt\" file is either corrupt or is not found.");
            return;
        }   
    } 

 




    public float[][] transpose()
    {
        float[][] temp = new float[cols][rows];
        for (int col = 0; col < rows; col++) {
            for (int row = 0; row < cols; row++) {
                temp[row][col] = matrix[col][row];
            }
        }
        return temp;
    }

    public float[][] add(float[][] someOtherMatrix)
    {
        int rows2 = getNumOfRowsCols(someOtherMatrix)[0];
        int cols2 = getNumOfRowsCols(someOtherMatrix)[1];

        if (!(rows == rows2 && cols == cols2)) {
            System.out.println("Error, cannot add matrices that are not the same size.");
            return new float[][] { };
        }
        else {
            float[][] temp = new float[rows][cols];
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    temp[row][col] = matrix[row][col] + someOtherMatrix[row][col];
                }
            }
            return temp;
        }
    }

    public float[][] subtract(float[][] someOtherMatrix)
    {
        int rows2 = getNumOfRowsCols(someOtherMatrix)[0];
        int cols2 = getNumOfRowsCols(someOtherMatrix)[1];

        if (!(rows == rows2 && cols == cols2)) {
            System.out.println("Error, cannot subtract matrices that are not the same size.");
            return new float[][] { };
        }
        else {
            float[][] temp = new float[rows][cols];
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    temp[row][col] = matrix[row][col] - someOtherMatrix[row][col];
                }
            }
            return temp;
        }
    }

    public float[][] multiply(float scalar)
    {
        float[][] temp = new float[rows][cols];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                temp[row][col] = scalar * matrix[row][col];
            }
        }
        return temp;
    }

    public float[][] multiply(float[][] someOtherMatrix) 
    {
        int rows2 = getNumOfRowsCols(someOtherMatrix)[0];
        int cols2 = getNumOfRowsCols(someOtherMatrix)[1];

        if (rows2 != cols) { 
            System.out.println("Error, multiplication is impossible."); 
            return new float[][] { }; 
        }
        else {
            float[][] temp = new float[rows][cols2];
            for (int i = 0; i < rows; i++) { 
                for (int j = 0; j < cols2; j++) { 
                    for (int k = 0; k < rows2; k++) {
                        temp[i][j] += matrix[i][k] * someOtherMatrix[k][j]; 
                    }
                }
            }
            return temp;
        }
    }

    public int[] getNumOfRowsCols(float[][] matrix) 
    {
        int numOfRows = matrix.length;
        int numOfCols = 0;
        for (int row = 0; row < 1; row++) {
            numOfCols = matrix[row].length;
        }
        return new int[] {numOfRows, numOfCols};
    }

    public void prettyMatrix() 
    {
        for (int row = 0; row < matrix.length; row++) {
                for (int col = 0; col < matrix[row].length; col++) {
                    if (matrix[row][col] == (float)0.0) {
                        System.out.print("  |  0.0");
                    }
                    else {
                        System.out.printf("  |  %2.1f", matrix[row][col]);
                    }
                }
            System.out.print("  |");
            System.out.println();
        }
    }

    public void prettyMatrix(float[][] anotherMatrix) 
    {
        for (int row = 0; row < anotherMatrix.length; row++) {
                for (int col = 0; col < anotherMatrix[row].length; col++) {
                    if (anotherMatrix[row][col] == (float)0.0) {
                        System.out.print("  |  0.0");
                    }
                    else {
                        System.out.printf("  |  %2.1f", anotherMatrix[row][col]);
                    }
                }
            System.out.print("  |");
            System.out.println();
        }
    }

}